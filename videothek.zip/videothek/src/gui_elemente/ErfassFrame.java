package gui_elemente;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.border.Border;

public class ErfassFrame extends JFrame {
	
	public ErfassFrame (String titel) {
		
		setBackground(Color.black);
		setForeground(Color.black);
	}

}
