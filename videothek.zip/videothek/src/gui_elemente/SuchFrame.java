package gui_elemente;

import java.awt.Color;

import javax.swing.JFrame;

public class SuchFrame extends JFrame {

	
	public SuchFrame(String titel) {
		
		
		setBackground(Color.gray);
		setForeground(Color.cyan);
	}
}
